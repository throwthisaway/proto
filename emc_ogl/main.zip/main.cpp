#include <emscripten.h>
#include <iostream>
struct A {
	int a, b;
	double c,d;
	A(int a, int b) : a(a), b(b) {
#ifdef __EMSCRIPTEN__
		emscripten_log(EM_LOG_CONSOLE, "A ctor. %d %x", this->a, this);
#endif
	}
};

struct Particles {
	Particles() {
		static A a(1, 1);
		static A b(2, 2);
		static A c(3, 3);
		static A d(4, 4);
		static A e(5, 5);
	}
};

static A  a(0, 0);
static Particles p;
static A  b(6, 6);
int main(int argc, char** argv) {
	std::cerr << "";
	return 0;
}